#!/bin/bash

# Use 'sudo -E ./setup.sh' to include environment variables

if [ -z ${RTE_SDK} ] ; then
	echo "*** RTE_SDK is not set, did you forget to do 'sudo -E ./setup.sh'"
	exit 1
fi
sdk=${RTE_SDK}

if [ -z ${RTE_TARGET} ]; then
	echo "*** RTE_TARGET is not set, did you forget to do 'sudo -E ./setup.sh'"
	exit 1
else
	target=${RTE_TARGET}
fi

echo "Using directory: "$sdk"/"$target

function nr_hugepages_fn {
    sudo echo /sys/devices/system/node/node${1}/hugepages/hugepages-2048kB/nr_hugepages
}

function num_cpu_sockets {
    local sockets=0
    while [ -f $(nr_hugepages_fn $sockets) ]; do
		sockets=$(( $sockets + 1 ))
    done
    sudo echo $sockets
    if [ $sockets -eq 0 ]; then
	echo "Huge TLB support not found make sure you are using a kernel >= 2.6.34" >&2
	exit 1
    fi
}

sudo rm -fr /mnt/huge/*

NR_HUGEPAGES=$(( `sysctl -n vm.nr_hugepages` / $(num_cpu_sockets) ))
echo "Setup "$(num_cpu_sockets)" socket(s) with "$NR_HUGEPAGES" pages."
for socket in $(seq 0 $(( $(num_cpu_sockets) - 1 )) ); do
    sudo echo $NR_HUGEPAGES > $(nr_hugepages_fn $socket)
done

grep -i huge /proc/meminfo
sudo modprobe uio
echo "trying to remove old igb_uio module and may get an error message, ignore it"
sudo rmmod igb_uio
sudo insmod $sdk/$target/kmod/igb_uio.ko
echo "trying to remove old rte_kni module and may get an error message, ignore it"
sudo rmmod rte_kni
sudo insmod $sdk/$target/kmod/rte_kni.ko "lo_mode=lo_mode_ring"

name=`uname -n`
if [ $name == "supermicro" ]; then
	sudo -E $sdk/tools/dpdk_nic_bind.py -b igb_uio 06:00.0 06:00.1 08:00.0 08:00.1 87:00.0 87:00.1 89:00.0 89:00.1
	#sudo -E $sdk/tools/dpdk_nic_bind.py -b igb_uio 87:00.0 87:00.1 89:00.0 89:00.1
fi
$sdk/tools/dpdk_nic_bind.py --status

echo ""
echo "Command 'lspci | grep Ether' output for reference"
lspci |grep Ether
