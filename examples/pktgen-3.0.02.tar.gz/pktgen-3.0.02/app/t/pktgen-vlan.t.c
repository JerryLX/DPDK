/*
 * SOURCE: pktgen-vlan.c
 * STUB: pktgen-arp.h pktgen-ipv4.h pktgen-ipv6.h
 *
 * LIBS:
 */

#include "pktgen.h"

pktgen_t pktgen;

/* Test driver */
int
main(void) {
	plan(1);
	ok(1, "ok works");

	done_testing();
	return 0;
}
