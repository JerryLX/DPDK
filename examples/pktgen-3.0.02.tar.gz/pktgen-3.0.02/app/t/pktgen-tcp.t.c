/*
 * SOURCE: pktgen-tcp.c
 *
 * LIBS: libwr_common
 */

/* Test driver */
int
main(void) {
	plan(1);
	ok(1, "ok works");

	done_testing();
	return 0;
}
