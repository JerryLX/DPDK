/*
 * SOURCE: pktgen-ipv6.c
 * LIBS:
 */

/* Test driver */
int
main(void) {
	plan(1);
	ok(1, "ok works");

	done_testing();
	return 0;
}
